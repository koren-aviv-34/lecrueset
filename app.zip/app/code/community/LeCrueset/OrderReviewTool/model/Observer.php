<?php
/**
 Our class name should follow the directory structure of our Observer.php model, 
starting from the namespace, replacing directory separators with underscores. 
The directory of ousr Observer.php is following:
 app/code/local/LeCrueset/OrderReviewTool/Model/Observer.php 
 */
class LeCrueset_OrderReviewTool_Model_Observer
{
// Magento passes a Varien_Event_Observer object as the first parameter of dispatched events.
public function main(Varien_Event_Observer $observer)
{
	// Get the number of days to check for the Order Interval 
	// from the system configuration page
	$orderInterval = $this->getOrderInterval();

	// Prepare the date from which the count start for retrieving the order
	$orderDateXDaysAgo	= date("Y-m-d H:i:s",strtotime("-$orderInterval days"));

	// Retrieve all the orders which were created before the date in $orderDateXDaysAgo
	$orderCollection = Mage::getModel("sales/order")->getCollection()
	->addFieldToSelect('*')
	->addFieldToFilter('created_at', array('lt' => $orderDateXDaysAgo))
	->setOrder('created_at', 'desc')
	;

	//Loop on all the Orders created more than X days ago
	//And send an email

	foreach ($orderCollection as $_order)
	{


	}


	
}


/**
Get the order past days X interval 
*/
private function getOrderInterval()
{
	$scopeId = 0;
	//default interval is 14 days
	$orderInterval = 14; 
	//$orderInterval  = Mage::getStoreConfig('design/social-meta-tags/design/custom/description')
	$currentScope = 'default';
	return $orderInterval;
}

/**
Set the fact that an email was sent to the customer,
 to avoid sending an email twice
*/
private function setCustomerEmailSent()
{


}

/**
Send a notification email to the customer about the survey link
*/
private function sendEmail()
{

}

/**
Create a view which will show the approved reviews randomly in the frontend
*/
private function showApprovefReviews()
{


}


}

?>